import game.CHOICES;

import java.awt.*;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println(" Enter your choice: \"Камень\", \"Ножницы\", \"Бумага\" ");
        Scanner scanner = new Scanner(System.in);
        Random rnd = new Random();
        String choice = scanner.nextLine();
        CHOICES comp = CHOICES.valueOf(choice.toUpperCase());
        CHOICES user = switch (comp) {

           
        }




    }
}

//Задание 2.
//Напишите консольную игру «Камень, ножницы, бумага».
// Пользователь вводит свой выбор (в виде строки или числа).
// Программа случайным образом делает свой выбор и выводит на экран.
// Далее программа показывает, кто победитель – пользователь или программа.