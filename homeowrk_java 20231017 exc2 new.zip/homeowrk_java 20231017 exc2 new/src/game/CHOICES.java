package game;

public enum CHOICES {
    КАМЕНЬ,
    НОЖНИЦЫ,
    БУМАГА
}
